# Estante — pacote para publicar

Cinco arquivos. Sem build, sem servidor de aplicação, sem banco.

    index.html            a aplicação inteira
    sw.js                 service worker (offline e cache da Scryfall)
    manifest.webmanifest  instalação como app
    icon-512.png          ícone
    icon.svg              ícone vetorial

## Por que precisa ser publicado

A Scryfall só libera CORS quando a página tem origem http válida.
Aberto como arquivo (`file://`) o navegador não envia origem, e a
requisição é bloqueada antes de sair. Não há correção possível no código.

## Publicar em 4 passos (GitHub Pages)

1. Crie um repositório público novo em github.com — pode ser pelo celular.
2. "Add file" → "Upload files" → envie os cinco arquivos desta pasta.
3. Settings → Pages → Source: `Deploy from a branch` → branch `main`, pasta `/ (root)` → Save.
4. Aguarde um minuto e abra `https://SEU-USUARIO.github.io/SEU-REPO/`.

Alternativas equivalentes: Cloudflare Pages, Netlify, Vercel — todas aceitam
arrastar a pasta.

## Depois de publicado

- A busca na Scryfall funciona.
- O Chrome oferece **Instalar** e o botão aparece na barra da aplicação.
- Instalado, abre em tela cheia e funciona offline com o que já visitou.
- O service worker guarda respostas da Scryfall por 7 dias e as artes
  indefinidamente, então a segunda consulta é instantânea.
